import _Home from "./_Home"
function page() {
  return (
    <div>
      <_Home />
    </div>
  );
}

export default page;
