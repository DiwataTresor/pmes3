import React from 'react'

const SectionAccessoire = () => {
  return (
    <div>
        {/* <div className="flex flex-row border border-slate-500 rounded-lg text-orange-300">
             <div></div>
        </div> */}
    </div>
  )
}

export default SectionAccessoire