import LoadingPage from "@/app/components/LoadingPage"
const loading=()=>{
    return(
        <LoadingPage />
    )
}
export default loading