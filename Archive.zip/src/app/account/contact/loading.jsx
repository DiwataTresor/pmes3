import LoadingPage from "./../../components/LoadingPage"
const loading=()=>{
    return(
        <LoadingPage />
    )
}
export default loading